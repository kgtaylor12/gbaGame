/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 beach beach.png 
 * Time-stamp: Tuesday 04/05/2022, 02:07:00
 * 
 * Image Information
 * -----------------
 * beach.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEACH_H
#define BEACH_H

extern const unsigned short beach[38400];
#define BEACH_SIZE 76800
#define BEACH_LENGTH 38400
#define BEACH_WIDTH 240
#define BEACH_HEIGHT 160

#endif

