/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 star star.png 
 * Time-stamp: Tuesday 04/05/2022, 01:42:44
 * 
 * Image Information
 * -----------------
 * star.png 5@4
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "star.h"

const unsigned short star[20] =
{
	0x7fff,0x7fff,0x4f5d,0x7fff,0x7fff,0x5f9e,0x473c,0x0e99,0x473c,0x5b9d,0x7fff,0x477f,0x2b3d,0x371c,0x7fff,0x7fff,
	0x477e,0x77ff,0x53bf,0x7fff
};

