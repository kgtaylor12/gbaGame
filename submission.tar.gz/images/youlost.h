/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 youlost You lost.png 
 * Time-stamp: Monday 04/04/2022, 06:04:03
 * 
 * Image Information
 * -----------------
 * You lost.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YOULOST_H
#define YOULOST_H

extern const unsigned short Youlost[38400];
#define YOULOST_SIZE 76800
#define YOULOST_LENGTH 38400
#define YOULOST_WIDTH 240
#define YOULOST_HEIGHT 160

#endif

