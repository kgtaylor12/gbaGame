/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 star star.png 
 * Time-stamp: Tuesday 04/05/2022, 01:42:44
 * 
 * Image Information
 * -----------------
 * star.png 5@4
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAR_H
#define STAR_H

extern const unsigned short star[20];
#define STAR_SIZE 40
#define STAR_LENGTH 20
#define STAR_WIDTH 5
#define STAR_HEIGHT 4

#endif

